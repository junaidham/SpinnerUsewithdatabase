package com.android.junaid.spinneruses;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.junaid.spinneruses.spinner.SpinnerArraydata;
import com.android.junaid.spinneruses.spinner.SpinnerMain;
import com.android.junaid.spinneruses.spinnerData.AddingSpinnerData_SQLite;

public class MainActivity extends Activity implements View.OnClickListener {

        Button btnCustomSpinner;
        Button btnSpinner1;
        Button btnSpinner2;
        Button btnSpinner3;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            btnCustomSpinner = (Button) findViewById(R.id.btnCustomSpinner);
            btnSpinner1 = (Button) findViewById(R.id.btnSpinner1);
            btnSpinner2 = (Button) findViewById(R.id.btnSpinner2);
            btnSpinner3 = (Button) findViewById(R.id.btnSpinner3);

            btnCustomSpinner.setOnClickListener(this);
            btnSpinner1.setOnClickListener(this);
            btnSpinner2.setOnClickListener(this);
            btnSpinner3.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnCustomSpinner:
                    break;

                case R.id.btnSpinner1:
                    Intent in1 = new Intent(MainActivity.this, SpinnerMain.class);
                    startActivity(in1);
                    break;
                case R.id.btnSpinner2:
                    Intent in2 = new Intent(MainActivity.this, SpinnerArraydata.class);
                    startActivity(in2);
                    break;
                case R.id.btnSpinner3:
                    Intent in3 = new Intent(MainActivity.this, AddingSpinnerData_SQLite.class);
                    startActivity(in3);
                    break;
            }

        }
    }

