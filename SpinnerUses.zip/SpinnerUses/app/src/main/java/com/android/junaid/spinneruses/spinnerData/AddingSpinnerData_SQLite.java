package com.android.junaid.spinneruses.spinnerData;
/**
 * http://www.androidhive.info/2012/06/android-populating-spinner-data-from-sqlite-database/
 */


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.junaid.spinneruses.R;

import java.util.List;

public class AddingSpinnerData_SQLite extends Activity implements OnItemSelectedListener {
    EditText   editInput;
   Button btnAdd;
    Spinner spinnerData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_spinner_data__sqlite);

        //view id
        editInput = (EditText) findViewById(R.id.editInput);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        spinnerData = (Spinner) findViewById(R.id.spinnerData);

        // Spinner click listener
        spinnerData.setOnItemSelectedListener(this);
        // Loading spinner data from database
        loadSpinnerData();

        /**
         * Add new label button click listener
         * */
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String label = editInput.getText().toString();

                if (label.trim().length()>0) {
                    // database handler
                    DatabaseHandler databaseHandler = new DatabaseHandler(getApplicationContext());
                    // inserting new label into database
                    databaseHandler.insertLabel(label);
                    // making input filed text to blank
                    editInput.setText("");

                    // Hiding the keyboard
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(editInput.getWindowToken(), 0);

                    // loading spinner with newly added data
                    loadSpinnerData();
                }else {
                        Toast.makeText(getApplicationContext(), "Please enter label name",Toast.LENGTH_SHORT).show();
                    }
                }
        });
    }


    /**
     * Function to load the spinner data from SQLite database
     * */
    private void loadSpinnerData() {
   /*     // database handler
            DatabaseHandler databaseHandler = new DatabaseHandler(getApplicationContext());
        // Spinner Drop down elements
        List<String> lablesList = databaseHandler.getAllLabels();
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, R.layout.spinner_layout, lablesList);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinnerData.setAdapter(dataAdapter);*/

        // database handler
        DatabaseHandler db = new DatabaseHandler(getApplicationContext());
        // Spinner Drop down elements
        List<String> lablesList = db.getAllLabels();
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lablesList);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinnerData.setAdapter(dataAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String label = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "You selected: " + label, Toast.LENGTH_LONG).show();


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
