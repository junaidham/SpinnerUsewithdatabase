package com.android.junaid.spinneruses.spinner;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.android.junaid.spinneruses.R;


public class SpinnerArraydata extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner_arraydata);

        Spinner spinnerCountry = (Spinner) findViewById(R.id.spCountry);

        String[] countriesData = getResources().getStringArray(R.array.array_countries);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.row_array,R.id.text21, countriesData);
        spinnerCountry.setAdapter(adapter);


    }
}
