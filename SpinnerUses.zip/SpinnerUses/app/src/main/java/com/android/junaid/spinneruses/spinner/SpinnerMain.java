package com.android.junaid.spinneruses.spinner;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.junaid.spinneruses.R;

import java.util.ArrayList;

public class SpinnerMain extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner_main);

        // Create DataHelper object and insert some sample data
        DataHelper datahelper=new DataHelper(this);
        datahelper.insertData("Kandal");
        datahelper.insertData("Kep");
        datahelper.insertData("Koh Kong");
        datahelper.insertData("Takeo");

        // Get sample data from the database and display them in the spinner
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayList<String> list=datahelper.getAllData();
        ArrayAdapter<String> sAdapter=new ArrayAdapter<String>(this, R.layout.spinner_layout, R.id.text1, list);
        spinner.setAdapter(sAdapter);

        //Spinner item selection when use the OnItemSelectedListener
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ViewGroup vg=(ViewGroup)view;
                TextView tv=(TextView)vg.findViewById(R.id.text1);
                Toast.makeText(SpinnerMain.this, tv.getText().toString(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }
}
