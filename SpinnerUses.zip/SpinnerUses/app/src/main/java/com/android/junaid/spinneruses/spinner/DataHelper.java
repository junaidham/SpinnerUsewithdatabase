package com.android.junaid.spinneruses.spinner;
/**
 * http://www.worldbestlearningcenter.com/tips/Android-add-sqlite-data-to-spinner.htm
 * http://www.worldbestlearningcenter.com/tips/Android-Spinner-and-its-item-selection.htm
 *
 * If your application needs to use a Spinner to display data from a local SQLite database,
 * this Android tutorial is useful to you. In the example app below,
 * the database prodb is created. In the database, there is a table called tableCrud that store names of provinces(sName).
 * Then the names of provinces(sName) are read from the database to populate a Spinner
 * there are two method -insertData(),getAllData
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Branded on 5/6/2017.  sName
 */

public class DataHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "dbCrud";
    public static final String TABLE_Crud = "tableCrud";
    public static final int DATABASE_VERSION  = 1;

    public static final String CREATE_TableQuery  = "CREATE TABLE IF NOT EXISTS "+ TABLE_Crud + "(id INTEGER PRIMARY KEY AUTOINCREMENT, sName TEXT NULL UNIQUE)";

    public static final String DELETE_PRO="DROP TABLE IF EXISTS " + TABLE_Crud;


    public DataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table
        db.execSQL(CREATE_TableQuery);
    }

    //Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop older table if existed
        db.execSQL(DELETE_PRO);
        //Create tables again
        onCreate(db);
    }


    public void insertData(String sName) {
        // Open the database for writing
        SQLiteDatabase db = this.getWritableDatabase();
        // Start the transaction.
        db.beginTransaction();
        ContentValues values;

        try {
            values = new ContentValues();
            values.put("sName", sName);
            // Insert Row
            db.insert(TABLE_Crud, null, values);
            // Insert into database successfully.
            db.setTransactionSuccessful();

        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database
        }
    }

    public ArrayList<String> getAllData(){
        ArrayList<String> list=new ArrayList<String>();
        // Open the database for reading
        SQLiteDatabase db = this.getReadableDatabase();
        // Start the transaction.
        db.beginTransaction();
        try {
            String selectQuery = "SELECT * FROM "+ TABLE_Crud;
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount()>0){
                while (cursor.moveToNext()){
                    // Add province name to arraylist
                    String sName= cursor.getString(cursor.getColumnIndex("sName"));
                    list.add(sName);
                }
            }
          db.setTransactionSuccessful();
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database

        }
        return list;
    }
}
